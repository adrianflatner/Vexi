function thanksForTheForm(user, email){
	alert("Thank you for your feedback "+ user.value + ". You will be contacted at "+ email.value + " as soon as possible.");
}
